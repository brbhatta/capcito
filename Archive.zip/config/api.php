<?php

return [
    'remote_base_url' => env('API_BASE_URL', 'https://qa-app.capcito.com/api/v3/work-sample/invoices'),
];
