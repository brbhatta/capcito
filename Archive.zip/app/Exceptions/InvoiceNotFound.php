<?php

namespace App\Exceptions;

use Exception;

class InvoiceNotFound extends Exception
{

}
