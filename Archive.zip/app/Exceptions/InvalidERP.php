<?php

namespace App\Exceptions;

use Exception;

class InvalidERP extends Exception
{

}
