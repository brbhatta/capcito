<?php

namespace App\Enum;

enum ERP: string
{
    case FORT_SOCKS = 'fortsocks';
    case VIZMA = 'vizma';
}
